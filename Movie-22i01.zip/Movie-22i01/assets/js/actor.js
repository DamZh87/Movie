import { getWeather, getCurrency, footer } from './footer.js';
import { getActor } from './movieAPI.js';






//ПОЛУЧИТЬ ИНФОРМАЦИЮ ОБ АКТЕРЕ
getActor()

// ФУТЕР
footer()

// ПОГОДА ))

getWeather()

//КУРС ВАЛЮТ))
getCurrency()
